package cn.laowu.mod.client;

import cn.laowu.mod.LaoWuMod;
import cn.laowu.mod.genetics.CatAttributeData;
import cn.laowu.mod.genetics.CatTraitData;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;

/** Renders the supplied scanner and a live attribute panel directly on its screen. */
public final class CatScannerItemRenderer extends BlockEntityWithoutLevelRenderer {
    private static final ResourceLocation MODEL =
            LaoWuMod.id("models/item/cat_scanner.bbmodel");
    private static final ResourceLocation INACTIVE_TEXTURE =
            LaoWuMod.id("textures/item/cat_scanner_inactive.png");
    private static final ResourceLocation ACTIVE_TEXTURE =
            LaoWuMod.id("textures/item/cat_scanner_active.png");
    public CatScannerItemRenderer(BlockEntityRenderDispatcher dispatcher,
                                  EntityModelSet models) {
        super(dispatcher, models);
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext context, PoseStack pose,
                             MultiBufferSource buffers, int light, int overlay) {
        Cat target = targetedCat(stack, context);
        ResourceLocation bodyTexture = INACTIVE_TEXTURE;
        if (target != null) {
            var profile = CatAttributeData.read(target);
            if (profile.isPresent()) {
                bodyTexture = CatScannerTextureManager.resolve(target, profile.get(),
                        CatTraitData.read(target).orElse(cn.laowu.mod.genetics.CatTraitProfile.EMPTY));
            } else {
                bodyTexture = ACTIVE_TEXTURE;
            }
        }

        pose.pushPose();
        // ItemRenderer applies the builtin/entity half-block offset first.
        // Centre the supplied raw bounds (-13..9, 0..2, -2..10) explicitly.
        pose.translate(0.5D, 1.0D, 0.5D);
        pose.scale(-1.0F, -1.0F, 1.0F);
        pose.translate(0.125D, 0.0625D, -0.25D);
        RuntimeBlockbenchModel.get(MODEL).render(pose,
                buffers.getBuffer(RenderType.entityCutoutNoCull(bodyTexture)),
                light, overlay, RuntimeBlockbenchModel.GroupSelection.ALL,
                RuntimeBlockbenchModel.HeadMotion.NONE);

        pose.popPose();
    }

    private static Cat targetedCat(ItemStack stack, ItemDisplayContext context) {
        if (context != ItemDisplayContext.FIRST_PERSON_RIGHT_HAND
                && context != ItemDisplayContext.FIRST_PERSON_LEFT_HAND
                && context != ItemDisplayContext.THIRD_PERSON_RIGHT_HAND
                && context != ItemDisplayContext.THIRD_PERSON_LEFT_HAND) return null;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null
                || (minecraft.player.getMainHandItem() != stack
                && minecraft.player.getOffhandItem() != stack)
                || !(minecraft.hitResult instanceof EntityHitResult hit)
                || !(hit.getEntity() instanceof Cat cat)) return null;
        return cat;
    }

    @Override
    public void onResourceManagerReload(ResourceManager manager) {
        CatScannerTextureManager.clear();
        RuntimeBlockbenchModel.clearCache();
    }
}
