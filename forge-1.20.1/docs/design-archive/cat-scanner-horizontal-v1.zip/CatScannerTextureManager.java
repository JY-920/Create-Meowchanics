package cn.laowu.mod.client;

import cn.laowu.mod.LaoWuMod;
import cn.laowu.mod.genetics.CatAttributeEffects;
import cn.laowu.mod.genetics.CatAttributeProfile;
import cn.laowu.mod.genetics.CatStat;
import cn.laowu.mod.genetics.CatTraitProfile;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.entity.animal.Cat;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.InputStream;

/**
 * Composites live cat stats into the scanner's own top-face texture.
 *
 * <p>The old implementation rendered the stats as a second piece of geometry.
 * Even a tiny depth offset became conspicuous after aggressive item-display
 * rotations. Baking the pixels into the same texture as the scanner makes the
 * screen and its contents physically inseparable in every display context.</p>
 */
@OnlyIn(Dist.CLIENT)
public final class CatScannerTextureManager {
    private static final Logger LOGGER = LogUtils.getLogger();

    private static final ResourceLocation ACTIVE_TEXTURE =
            LaoWuMod.id("textures/item/cat_scanner_active.png");
    private static final ResourceLocation ATTRIBUTE_ICONS =
            LaoWuMod.id("textures/gui/cat_attribute_icons.png");
    private static final ResourceLocation NUMBER_GLYPHS =
            LaoWuMod.id("textures/gui/cat_stat_numbers.png");
    private static final ResourceLocation TIER_ICONS =
            LaoWuMod.id("textures/gui/cat_stat_tiers.png");
    private static final ResourceLocation LIVE_TEXTURE =
            LaoWuMod.id("dynamic/cat_scanner_screen");

    private static final int TEXTURE_SCALE = 8;
    private static final int PANEL_WIDTH = 71;
    private static final int PANEL_HEIGHT = 72;
    private static final int PANEL_TEXTURE_X = 28;
    private static final int PANEL_TEXTURE_Y = 4;
    private static final int ROW_Y = 13;
    private static final int ROW_SPACING = 9;

    private static String lastKey;
    private static boolean registered;

    public static ResourceLocation resolve(Cat cat, CatAttributeProfile profile,
                                           CatTraitProfile traits) {
        int[] current = new int[CatStat.values().length];
        int[] limits = new int[current.length];
        StringBuilder key = new StringBuilder(current.length * 9);
        for (int index = 0; index < current.length; index++) {
            CatStat stat = CatStat.values()[index];
            current[index] = CatAttributeEffects.effectiveValue(cat, profile, traits, stat);
            limits[index] = profile.potential(stat);
            key.append(current[index]).append('/').append(limits[index]).append(';');
        }

        String valueKey = key.toString();
        if (registered && valueKey.equals(lastKey)) return LIVE_TEXTURE;

        NativeImage composed = null;
        try {
            composed = compose(current, limits);
            var textures = Minecraft.getInstance().getTextureManager();
            if (registered) textures.release(LIVE_TEXTURE);
            textures.register(LIVE_TEXTURE, new DynamicTexture(composed));
            composed = null; // DynamicTexture owns the image after registration.
            registered = true;
            lastKey = valueKey;
            return LIVE_TEXTURE;
        } catch (Exception exception) {
            if (composed != null) composed.close();
            LOGGER.error("Could not compose the cat scanner screen", exception);
            return ACTIVE_TEXTURE;
        }
    }

    private static NativeImage compose(int[] current, int[] limits) throws IOException {
        try (NativeImage base = load(ACTIVE_TEXTURE);
             NativeImage attributes = load(ATTRIBUTE_ICONS);
             NativeImage numbers = load(NUMBER_GLYPHS);
             NativeImage tiers = load(TIER_ICONS)) {
            NativeImage output = new NativeImage(base.getWidth() * TEXTURE_SCALE,
                    base.getHeight() * TEXTURE_SCALE, true);
            try {
                for (int y = 0; y < output.getHeight(); y++) {
                    for (int x = 0; x < output.getWidth(); x++) {
                        output.setPixelRGBA(x, y,
                                base.getPixelRGBA(x / TEXTURE_SCALE, y / TEXTURE_SCALE));
                    }
                }

                for (int row = 0; row < CatStat.values().length; row++) {
                    int y = ROW_Y + row * ROW_SPACING;
                    int now = current[row];
                    int limit = limits[row];
                    boolean nowAbnormal = now < 0 || now > 999;
                    boolean limitAbnormal = limit < 0 || limit > 999;

                    drawSprite(output, attributes, 5, y, 8, 8,
                            row * 8, 0);
                    drawNumber(output, numbers,
                            nowAbnormal ? "???" : Integer.toString(now), 29, y + 1);
                    drawSprite(output, tiers, 32, y + 1, 6, 6,
                            tierIndex(now, nowAbnormal) * 6, 0);
                    drawNumber(output, numbers,
                            limitAbnormal ? "???" : Integer.toString(limit), 56, y + 1);
                    drawSprite(output, tiers, 59, y + 1, 6, 6,
                            tierIndex(limit, limitAbnormal) * 6, 0);
                }
                return output;
            } catch (RuntimeException exception) {
                output.close();
                throw exception;
            }
        }
    }

    private static void drawNumber(NativeImage target, NativeImage glyphs,
                                   String text, int rightExclusive, int y) {
        int width = 7 + Math.max(0, text.length() - 1) * 4;
        int x = rightExclusive - width;
        for (int index = 0; index < text.length(); index++) {
            char character = text.charAt(index);
            int glyph = character == '?' ? 0 : 1 + character - '0';
            drawSprite(target, glyphs, x + index * 4, y, 7, 7,
                    glyph * 7, 0);
        }
    }

    private static void drawSprite(NativeImage target, NativeImage source,
                                   int x, int y, int width, int height,
                                   int u, int v) {
        for (int sourceY = 0; sourceY < height; sourceY++) {
            for (int sourceX = 0; sourceX < width; sourceX++) {
                int colour = source.getPixelRGBA(u + sourceX, v + sourceY);
                int alpha = colour >>> 24;
                if (alpha == 0) continue;

                int targetX = PANEL_TEXTURE_X + x + sourceX;
                // The scanner's authored top-face UV runs from V=10 to V=0.
                // Flip the composed panel once in texture space so it reads
                // upright on the model without any second render plane.
                int targetY = PANEL_TEXTURE_Y + PANEL_HEIGHT - 1 - (y + sourceY);
                if (targetX < 0 || targetX >= target.getWidth()
                        || targetY < 0 || targetY >= target.getHeight()) continue;
                target.setPixelRGBA(targetX, targetY,
                        blend(target.getPixelRGBA(targetX, targetY), colour));
            }
        }
    }

    private static int blend(int background, int foreground) {
        int alpha = foreground >>> 24;
        if (alpha >= 255) return foreground;
        int inverse = 255 - alpha;
        int red = ((foreground & 0xff) * alpha + (background & 0xff) * inverse) / 255;
        int green = (((foreground >>> 8) & 0xff) * alpha
                + ((background >>> 8) & 0xff) * inverse) / 255;
        int blue = (((foreground >>> 16) & 0xff) * alpha
                + ((background >>> 16) & 0xff) * inverse) / 255;
        int backgroundAlpha = background >>> 24;
        int outputAlpha = alpha + backgroundAlpha * inverse / 255;
        return outputAlpha << 24 | blue << 16 | green << 8 | red;
    }

    private static NativeImage load(ResourceLocation location) throws IOException {
        ResourceManager resources = Minecraft.getInstance().getResourceManager();
        try (InputStream stream = resources.open(location)) {
            return NativeImage.read(stream);
        }
    }

    private static int tierIndex(int value, boolean abnormal) {
        if (abnormal) return 0;
        if (value < 20) return 1;
        if (value < 40) return 2;
        if (value < 60) return 3;
        if (value < 80) return 4;
        if (value < 100) return 5;
        return 6;
    }

    public static void clear() {
        if (registered) Minecraft.getInstance().getTextureManager().release(LIVE_TEXTURE);
        registered = false;
        lastKey = null;
    }

    private CatScannerTextureManager() {}
}
